/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schoolregistration;

import java.util.ArrayList;

/**
 *
 * @author lizziekim
 */
public class Courses {
    
    private String courseName; //Assign the variable of course name
    private Teachers teacher; //Assign a teacher object to the course 
    private ArrayList<Students> studentList = new ArrayList<Students>(); //Assign a list of students in this course
    private String courseCode; //Assign the variable of the course code 
    public int capNum;
    private int mark, period;
    
    public Courses(String courseName, String coursecode, int capNum, int period)
    {
        this.courseName = courseName;
        this.courseCode = coursecode;
        this.capNum = capNum;
        this.mark = 0;
        this.period = period;
      
    }
    
    public boolean checkAdmittance(Students student)//to check if they are already in the class 
    {
        if (studentList.contains(student))
        {
            return true; //return true if the student is in the class 
        }
        return false; //returning false if not 
    }
    
    public boolean checkFullness() //To see if the class is available to add fo student 
    {
        if (capNum < studentList.size()) //If it is not full 
        {
            return true;
        }
        else
        {
            return false;
        }
    }    
    
    public void addStudents(Students student) //Method for adding students to this course
    {
        if (studentList.contains(student)) //Checking if the student is already is in the class or not 
        {  
            System.out.println("This student is already in this class!."); //Let the user know 
        }
        if (studentList.size() >= capNum) //If the class has already reached its capacity 
        {  
            System.out.println("This student cannot join this class as it is full."); //Let the user know 
        }
        studentList.add(student); 
        
    }
    
    public void dropStudents(Students student) //Method for dropping students 
    {
        if (studentList.contains(student)) //Check if the student is actually in the class 
        {
            studentList.remove(student); //Remove the student 
        }
        else
        {
            System.out.println("This student is not in this class."); //Let the user know 
        }
    }

    public void setTeacher(Teachers Teacher) {
        this.teacher = Teacher;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public void setCapNum(int capNum) {
        this.capNum = capNum;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public void setMark(int newMark) {
        this.mark = newMark;
    }
    

    public int getMark() {
        return mark;
    }
    
    
    
    public String getCourse()
    {
        return courseName;
    }

    public String getCourseCode() {
        return courseCode;
    }
    
    public int getCapNum()
    {
        return capNum;
    }
    
    public Teachers getTeacher()
    {
        return teacher;
    }

    public int getPeriod() {
        return period;
    }
    
    

    @Override
    public String toString() {
        
        return "Course name: " + getCourse() + "\n" + "Course code: " + getCourseCode() + "\nTeacher: " + "\n" + teacher;
        
                
    }
    
    
    
    
   

    
}
