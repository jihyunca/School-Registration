/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schoolregistration;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;


public class Lockers {
    
    private int combo;
    private static AtomicInteger nextLocker=new AtomicInteger(); //Accumulate the numbers 
    private int lockerNum;
    
    
    public Lockers(int combo)
    {
       
        this.lockerNum = lockerNum;
        this.combo = combo;
        lockerNum = nextLocker.incrementAndGet();
        
    }

    public void setCombo(int combo) {
        this.combo = combo;
    }
    
    
    
    public int getLockerNum()
    {
        return lockerNum;
    }

    public int getCombo() {
        return combo;
    }

    @Override
    public String toString() {
        return "The locker's number is: " + lockerNum + "\n" + "The combo is: " + combo; //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
