/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schoolregistration;
import java.util.ArrayList;
import java.io.*;


/*
    Lizzie Kim's school registration program 
*/
public class SchoolRegistration {

    public static boolean checkMainMenu = true;
  
//    public static timeTable timetable;
    
    public static void main(String[] args) throws IOException {
        
        //new Menu().setVisible(true);
        
        
        ArrayList STLstudents = new ArrayList<Students>(); //ArrayList of object students
        ArrayList STLteachers = new ArrayList<Teachers>(); //Arraylist of object teachers
        ArrayList STLcourses = new ArrayList<Courses>(); //Arraylist of object courses

        //Added couress in Mathematics 
        STLcourses.add(new Courses("Data Management","MDM4U1", 28, 1));
        STLcourses.add(new Courses("Advanced Functions", "MH4RU1", 28, 2));
        STLcourses.add(new Courses("Calculus", "MCV4U1", 28, 3));
        STLcourses.add(new Courses("Functions 11", "MCR3U1", 30, 3));
        STLcourses.add(new Courses("Math 10", "MPM2D1", 30, 4));
        STLcourses.add(new Courses("Math 9", "MPM1D1", 30, 4));
       
        //Added courses in English
        STLcourses.add(new Courses("English 12", "ENG4U1", 30, 1));
        STLcourses.add(new Courses("English 11", "ENG3U1", 30, 2));
        STLcourses.add(new Courses("English 10", "ENG2D1", 30, 3));
        STLcourses.add(new Courses("English 9", "ENG1D1", 30, 4));
        
        //Added courses in Social Science
        STLcourses.add(new Courses("Geography 12", "CGW4U1", 25, 1));
        STLcourses.add(new Courses("Geography 9", "CGC1D1", 30, 2));
        STLcourses.add(new Courses("World History 12", "", 25, 2));
        STLcourses.add(new Courses("Families in Canada 12", "HHS4U1", 25, 3));
        STLcourses.add(new Courses("Challenge and Change 12","HSB4U1", 25, 4));
        
        //Added courses in Science 
        STLcourses.add(new Courses("Physics 12", "SPH4U1", 28, 1));
        STLcourses.add(new Courses("Chemistry 12", "SCH4U1", 28, 2));
        STLcourses.add(new Courses("Science 10", "SNC2D1", 30, 3));
        STLcourses.add(new Courses("Science 9", "SNC1D1", 30, 4));
        
        //Added courses in Other
        STLcourses.add(new Courses("Computer Science 12", "ICS4U1", 25, 1)); 
        STLcourses.add(new Courses("Computer Science 11", "ICS3U1", 30, 2));
        
        //------------Adding some students initially--------//
       
        Students student1  = new Students(new Lockers(122234), "Lizzie", "Kim", "12/14/2000", "16", "80", "222", "811");
        STLstudents.add(student1);
        student1.setSpecialInfo(new SpecialInfo("None", "None", "None", "None"));
        Students student2 = new Students(new Lockers(213000), "John", "Johnson", "08/03/2000", "17", "50", "12", "333");
        STLstudents.add(student2);
        student2.setSpecialInfo(new SpecialInfo("None", "None", "Peanuts", "None"));
        Students student3 = new Students(new Lockers(312334), "Karen", "Thomas", "09/08/2002", "15", "30", "125", "555");
        STLstudents.add(student3);
        student3.setSpecialInfo(new SpecialInfo("None", "None", "None", "None"));
        
        
        //------------Adding some teachers inititally--------//
        STLteachers.add(new Teachers("Anthony", "Ganuelas", "111", "911"));
        STLteachers.add(new Teachers("Josephine", "Florio", "333", "124"));
        STLteachers.add(new Teachers("John", "Dawson", "555", "126"));
        STLteachers.add(new Teachers("Veronica", "Chan", "999", "310"));
       
        String answer; 
        
        System.out.println("Welcome to the school registration system.");
        System.out.println("When students register, they will be assigned a student number. This should be used for modifying any of their courses or information.");
        System.out.println("In this registration system, there will be no OEN numbers or prerequisites.");
        
        do
        {
            answer = mainMenu();
            if (answer.equals("1"))
            {
                registerStudent(STLstudents); //Prompt the register screeen
            }
            if (answer.equals("2"))
            {
                teacherRegistration(STLteachers); //Prompt the teacher register screen
            }
            if (answer.equals("3"))
            {
                courseMenu(STLstudents, STLcourses, STLteachers); //Prompt the course menu
            }
            if (answer.equals("4"))
            {
                searchMenu(STLstudents); //Prompt the search menu 
            }
            if (answer.equals("5"))
            {
                updateStudentInfo(STLstudents); //Prompt the student info update screen
            }
            if (answer.equals("6"))
            {
                updateMarkMenu(STLstudents, STLcourses); //Prompt the update mark menu
            }
            if (answer.equals("7"))
            {
                displayCourses(STLcourses); //Display all the courses that are available 
            }
            if (answer.equals("8"))
            {
                updateSchoolMenu(STLstudents, STLteachers); //Prompt the update school menu
            }
            if (answer.equals("9"))
            {
                displayTeacher(STLteachers); //Display all the teachers in the school registered
            }
            if (answer.equals("10"))
            {
                searchTeacher(STLteachers); //Prompt the search teacher menu
            }
            if (answer.equals("11"))
            {
                updateTeacherInfo(STLteachers); //Prompt the update teacher info screen 
            }
            if (answer.equals("12"))
            {
                teacherCourseMenu(STLcourses, STLteachers); //Prompt the teacher course menu 
            }
            if (answer.equals("0"))
            {
                System.out.println("See you later!");
                System.exit(0);
            }
            else if (checkMainMenu == true)
            {
                System.out.println("Please enter a valid number."); //If they are not entering the proper format, tell them to enter again
                mainMenu();
            }
            
        }while (true);
     
    }
    
    public static String mainMenu() throws IOException //This is the main menu the user will see 
    {
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        checkMainMenu = true;
        
        System.out.println("");
        System.out.println("Welcome to the school menu! What would you like to do?");
        System.out.println("-------Registration-------");
        System.out.println("[1.] Register a student");
        System.out.println("[2.] Register a teacher");
        System.out.println("");
        System.out.println("----Student Management----");
        System.out.println("[3.] Manage a student's course");
        System.out.println("[4.] Search for a student");
        System.out.println("[5.] Update student information");
        System.out.println("[6.] Update marks");
        System.out.println("");
        System.out.println("-----School Information----");
        System.out.println("[7.] Check all the available courses");
        System.out.println("[8.] Update School");
        System.out.println("");
        System.out.println("-----Teacher Management-----");
        System.out.println("[9.] Display all the teachers");
        System.out.println("[10.] Search for a teacher");
        System.out.println("[11.] Update teacher information");
        System.out.println("[12.] Manage teacher's courses");
        System.out.println("");
        System.out.println("");
        System.out.println("Please press 0 to quit.");
        
        String answer = stdin.readLine();
        return answer;
    }
    
    public static void updateMarkMenu(ArrayList<Students> Stlstudents, ArrayList<Courses> Stlcourses) throws IOException
    {
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        checkMainMenu = false; //So the main menu does not appear 
        boolean checkFormat = false; //This will help determine if the user has entered right format or not
        
        System.out.println("You have chosen to manage a student's marks.");
        System.out.println("1. Add a mark");
//        System.out.println("2. Look at student's average");
        System.out.println("Press 5 to go back to the main menu");
        System.out.println("");
        
        String answer = stdin.readLine();
        
        while (checkFormat == false)
        {
            if (answer.equals("1"))
            {
                addMark(Stlstudents, Stlcourses); //Let the user add marks 
                checkFormat = true;
            }

//            if (answer.equals("2"))
//            {
//                calculateAvg(Stlstudents, Stlcourses);
//                checkFormat = true;
//            }
            if (answer.equals("5"))
            {
                return;
            }
            else 
            {
                System.out.println("Please enter the right format.");
                answer = stdin.readLine();
            }
        }
    }
    
    public static void addMark(ArrayList<Students> Stlstudents, ArrayList<Courses> Stlcourses) throws IOException
    {
        checkMainMenu = false;
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        
        String alpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        
        System.out.println("What is the id of the student would you like to help? ");
        String answer = stdin.readLine();
        int answerInt = 0;
        String answerTwo;
        
        for (int i = 0; i < answer.length(); i++)
        {
            if (alpha.indexOf(answer.substring(i,i+1)) < 0)
            {
                answerInt = Integer.parseInt(answer);
            }
            else if (i == answer.length())
            {
                System.out.println("Please enter a proper ID.");
                answer = stdin.readLine();
            }
        }
        
        String newCourse = "";
        String numCheck = "1234567890";
        int check = 0;
        String checkMark;
        int mark;
        
        for (Students student: Stlstudents)
        {
            if (student.getId() == answerInt)
            {
                System.out.println("What course would they like to add the mark in for? ");
                newCourse = stdin.readLine();
                
                for (Courses course: Stlcourses)
                {
                    if (course.getCourse().equals(newCourse) && (course.checkAdmittance(student) == true))
                    {
                        System.out.println("What is the mark that should be inputted?");
                        checkMark = stdin.readLine();
                        
                        for (int i = 0; i < checkMark.length(); i++)
                        {
                            if (numCheck.indexOf(checkMark.substring(i, i+1)) >= 0)
                            {
                                check++;
                            }
                        }
                        if (check == checkMark.length())
                        {
                            mark = Integer.parseInt(checkMark);
                            course.setMark(Integer.parseInt(checkMark));
                            System.out.println("The mark has been inputted.");
                            return;
                        }
                        else
                        {
                            System.out.println("This is not the right format for a mark!");
                            return;
                        }
                    }
                    else if (course.getCourse().equals(newCourse) && course.checkAdmittance(student) == false)
                    {
                        System.out.println("This student is not in this class.");
                        return;
                    }
                }
                System.out.println("This course does not exist!");
                return;
            }
        }
        System.out.println("This student does not exist!");
        return;
    }
    
    public static void updateStudentInfo(ArrayList<Students> Stlstudents) throws IOException
    {
        /*
        
        This is a method that helps the user update a student's information
        */
        checkMainMenu = false;
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        
        int check = 0;
        int answerInt = 0;
        String answerTwo;
        String nums = "1234567890";
        boolean checkFormat = false;
        
        
        String alpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"; //To check for format 
        String bdayForm = "1234567890/"; //To check for format 
        boolean checkForm = false;
        int checkTwo = 0;
        
       
        System.out.println("What is the id of the student would you like to help? "); 
        String answer = stdin.readLine();
        while (checkFormat == false)
        {
            check = 0;
            for (int i = 0; i < answer.length(); i++)
            {
                if (nums.indexOf(answer.substring(i,i+1)) >= 0)
                {
                    check += 1;
                }
            }
            if (check != answer.length() || answer.equals(""))
            {
                System.out.println("This is not the correct format.");
                answer = stdin.readLine();
            }
            else
            {
                answerInt = Integer.parseInt(answer);
                checkFormat = true;
            }

        }
        
        for (Students student: Stlstudents) //Go through the list of students to find that student
        {
            String changedAnswer;
            if (student.getId() == answerInt)
            {
                System.out.println("Is this the student that you would like to change?");
                System.out.println("Please enter yes or no.");
                System.out.println(student.toString()); //Display student just in case it is not the student they were looking for 
                
                answer = stdin.readLine();
                
                if (answer.equalsIgnoreCase("yes"))
                {
                    /*
                    
                    This gives the user the option to change certain information
                    */
                    System.out.println("What kind of information are you looking to change?");
                    System.out.println("1. First name");
                    System.out.println("2. Last name");
                    System.out.println("3. Birthday");
                    System.out.println("4. Service hours");
                    System.out.println("5. Address");
                    System.out.println("6. Phone number");
                    System.out.println("7. Special Information");
                    System.out.println("8. Locker Combo");
                    answer = stdin.readLine();
                    
                    if (answer.equals("1"))
                    {
                        System.out.println("What would you like to change the first name to?");
                        changedAnswer = stdin.readLine();
                        
                        while (checkForm == false)
                        {
                            checkTwo = 0;
                            for (int i = 0; i < changedAnswer.length(); i++)
                            {
                                if (alpha.indexOf(changedAnswer.substring(i,i+1)) >= 0)
                                {
                                    checkTwo += 1;
                                }
                            }
                            if (checkTwo != changedAnswer.length() || changedAnswer.equals(""))
                            {
                                System.out.println("This is not the correct format for a name.");
                                changedAnswer = stdin.readLine();
                            }
                            else
                            {
                                checkForm = true;
                            }

                        }
                        student.setName(changedAnswer);
                        System.out.println("You have changed the first name.");
                        return;
                    }
                    if (answer.equals("2"))
                    {
                        
                        checkForm = false;
                        System.out.println("What would you like to change the last name to?");
                        changedAnswer = stdin.readLine();

                        while (checkForm == false)
                        {
                            checkTwo = 0;
                            for (int i = 0; i < changedAnswer.length(); i++)
                            {
                                if (alpha.indexOf(changedAnswer.substring(i,i+1)) >= 0)
                                {
                                    checkTwo += 1;
                                }
                            }
                            if (checkTwo != changedAnswer.length())
                            {
                                System.out.println("This is not the correct format for a last name.");
                                changedAnswer = stdin.readLine();
                            }
                            else
                            {
                                checkForm = true;
                            }

                        }
                        student.setLastName(changedAnswer);
                        System.out.println("You have changed the last name.");
                        return;
                    }
                    if (answer.equals("3"))
                    {
                        
                        checkForm = false;
                        System.out.println("What would you like to change the birthday to?");
                        changedAnswer = stdin.readLine();
                        while (checkForm == false)
                        {
                            checkTwo = 0;
                            for (int i = 0; i < changedAnswer.length(); i++)
                            {
                                if (bdayForm.indexOf(changedAnswer.substring(i,i+1)) >= 0)
                                {
                                    checkTwo += 1;
                                }
                            }
                            if (checkTwo != 10)
                            {
                                System.out.println("This is not the correct format for a birthday.");
                                changedAnswer = stdin.readLine();
                            }
                            else
                            {
                                checkForm = true;
                            }

                        }
                        student.setBirthday(changedAnswer);
                        System.out.println("You have changed the birthday.");
                        return;
                    }
                    if (answer.equals("4"))
                    {
                        System.out.println("What would you like to change the service hours to?");
                        changedAnswer = stdin.readLine();
                        student.setServiceHours(changedAnswer);
                        System.out.println("You have changed the service hours.");
                        return;
                    }
                    if (answer.equals("5"))
                    {
                        System.out.println("What would you like to change the address to?");
                        changedAnswer = stdin.readLine();
                        student.setAddress(changedAnswer);
                        System.out.println("You have changed the address.");
                        return;
                    }
                    if (answer.equals("6"))
                    {
                        
                        checkForm = false;
                        System.out.println("What would you like to change the phone number to?");
                        changedAnswer = stdin.readLine();
                        while (checkForm == false)
                        {
                            checkTwo = 0;
                            for (int i = 0; i < changedAnswer.length(); i++)
                            {
                                if (alpha.indexOf(changedAnswer.substring(i,i+1)) < 0)
                                {
                                    checkTwo += 1;
                                }
                            }
                            if (checkTwo != 10)
                            {
                                System.out.println("This is not the correct format for a phone number.");
                                changedAnswer = stdin.readLine();
                            }
                            else
                            {
                                checkForm = true;
                            }

                        }
                        student.setPhoneNumber(changedAnswer);
                        System.out.println("You have changed the phone number.");
                        return;
                    }
                    if (answer.equals("7"))
                    {
                        System.out.println("You have chosen to update special information.");
                        System.out.println("[1.] Accomodation");
                        System.out.println("[2.] Physical needs");
                        System.out.println("[3.] Allergies");
                        System.out.println("[4.] Epipen");
                        changedAnswer = stdin.readLine();
                        String newInfo;
                        
                        if (changedAnswer.equals("1"))
                        {
                            System.out.println("What accomodations does the student need?");
                            newInfo = stdin.readLine();
                            SpecialInfo info = student.getSpecialInfo();
                            String physicals = info.getPhysical();
                           
                            String allergies = info.getAllergy();
                            String epipen = info.getEpipen();
                            student.setSpecialInfo(new SpecialInfo(newInfo, physicals, allergies, epipen));
                            System.out.println("You have changed their accomodations.");
                            return;
                        }
                        if (changedAnswer.equals("2"))
                        {
                            System.out.println("What physical needs does the student have?");
                            SpecialInfo info = student.getSpecialInfo();
                            
                            student.setSpecialInfo(new SpecialInfo(info.getAccomodation(), stdin.readLine(), info.getAllergy(), info.getEpipen()));
                        }
                        if (changedAnswer.equals("3"))
                        {
                            System.out.println("What allergies does the student have?");
                            SpecialInfo info = student.getSpecialInfo();
                            
                            student.setSpecialInfo(new SpecialInfo(info.getAccomodation(), info.getPhysical(), stdin.readLine(), info.getEpipen()));
                        }
                        if (changedAnswer.equals("4"))
                        {
                            System.out.println("What epipens does the student have?");
                            SpecialInfo info = student.getSpecialInfo();
                            
                            student.setSpecialInfo(new SpecialInfo(info.getAccomodation(), info.getPhysical(), info.getAllergy(), stdin.readLine()));
                        }
                        else
                        {
                            System.out.println("This is not the right format.");
                            return;
                        }
                    }
                    if (answer.equals("8"))
                    {
                        System.out.println("You have chosen to change the locker combination.");
                        checkForm = false;
                        System.out.println("Enter your locker combination (6 digits): ");
                        String lockerCombo = stdin.readLine();
                        int lockCombo = 0;
                        while (checkForm == false)
                        {
                            checkTwo = 0;
                            for (int i = 0; i < lockerCombo.length(); i++)
                            {
                                if (alpha.indexOf(lockerCombo.substring(i,i+1)) < 0)
                                {
                                    checkTwo += 1;
                                }
                            }
                            if (checkTwo != 6)
                            {
                                System.out.println("This is not the correct format for a locker combo.");
                                System.out.println("Example should be: 021432");
                                lockerCombo = stdin.readLine();
                            }
                            else
                            {
                                lockCombo = Integer.parseInt(lockerCombo);
                                checkForm = true;
                            }
                            student.getLocker().setCombo(lockCombo);
                            System.out.println("You have successfully changed the locker combination.");
                            return;
                        }
                        
                    }
                    else
                    {
                        System.out.println("Please enter a valid number.");
                        answer = stdin.readLine();
                    }
                    
                    
                }
                else if (answer.equalsIgnoreCase("no"))
                {
                    System.out.println("Try again!");
                    return;
                }
                else
                {
                    System.out.println("This is not the right format. Please enter yes or no.");
                    answer = stdin.readLine();
                }
            }
        }      
    }
    
    public static void updateSchoolMenu(ArrayList<Students> Stlstudents, ArrayList<Teachers> Stlteachers) throws IOException
    {
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        
        checkMainMenu = false; //Make the main menu disappear 
        
        System.out.println("You have chosen the school update menu!");
        System.out.println("1. Remove a student: ");
        System.out.println("2. Remove a teacher: ");
        System.out.println("Press 5 to return back to the main menu!");
        System.out.println("");
        
        String answer = stdin.readLine();
        
        if (answer.equals("1"))
        {
            removeStudent(Stlstudents); //Prompt the remove student screen
        }
        if (answer.equals("2"))
        {
            removeTeacher(Stlteachers); //Prompt the remove teacher screen
        }
        if (answer.equals("5"))
        {
            return;
        }
    }
    
    public static void displayTeacher(ArrayList<Teachers> Stlteachers) throws IOException
    {
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        
        checkMainMenu = false;
        
        System.out.println("");
        System.out.println("You have chosen to display all the teachers.");
        System.out.println("If you would like to go back to the main menu, press 5."
                + " Else, please press any key.");
        String answer = stdin.readLine();
        
        if (answer.equals("5"))
        {
            return;
        }
        
        for (Teachers teacher: Stlteachers) //Go through all the teachers in the list
        {
            System.out.println("Teacher: " + teacher.getFirstName() + " " + teacher.getLastName()); //Print all of their information 
            ArrayList<Courses> courseList = teacher.getCoursesList(); //This will also help retrive their courses
            for (int i = 0; i < courseList.size(); i++)
            {
                System.out.println(courseList.get(i).getCourse()); //Iterate through their courses and print the names of their courses
            }
            System.out.println("");
        }
    }
    
    public static void searchTeacher(ArrayList<Teachers> Stlteachers) throws IOException
    {
        checkMainMenu = false;
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        
        String firstName, lastName;
        
        System.out.println("You have chosen to look for a teacher.");
        System.out.println("Press 5 to go back to the main menu. Elsewise, press any key.");
        
        String answer = stdin.readLine();
        if (answer.equals("5"))
        {
            return;
        }
        
        else 
        {
            System.out.println("What is the teacher's first name? "); //Prompt for the teacher's first name
            firstName = stdin.readLine();
            System.out.println("What is the teacher's last name?"); //Prompt for the teacher's last name
            lastName = stdin.readLine();
           
            for (Teachers teacher: Stlteachers)
            {
                if (teacher.getFirstName().equalsIgnoreCase(firstName) && teacher.getLastName().equalsIgnoreCase(lastName)) //If the teacher's names add up
                {
                    
                    System.out.println(teacher.toString()); //Display the teacher's information 
                    ArrayList<Courses> courseList = teacher.getCoursesList(); //This will also help retrive their courses
                    for (int i = 0; i < courseList.size(); i++)
                    {
                        System.out.println(courseList.get(i).getCourse()); //Iterate through their courses and print the names of their courses
                    }
                    System.out.println("");
                    
                    return;
                }
            }
            System.out.println("The teacher does not exist!");//if this teacher cannot be found within the arraylist
            return;
        }
        
    }
    
    public static void updateTeacherInfo(ArrayList<Teachers> Stlteachers) throws IOException
    {
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        checkMainMenu = false;
        
        System.out.println("What is the first name of the teacher you would like to update?"); //Prompt for the teacher's first name
        String name = stdin.readLine();
        System.out.println("What is the last name of the teacher you would like to update?");//Prompt for the teacher's last name
        String lastName = stdin.readLine();
        String answer, changedAnswer;
        
        String alpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"; //to check for format
        String bdayForm = "1234567890/"; //to check for format 
        boolean check = false;
        boolean choices = false;
        int checkTwo = 0;
        
        
        
        
        for (Teachers teacher: Stlteachers) //Iterate through all the teachers in the list
        { 
            if (teacher.getFirstName().equalsIgnoreCase(name) && teacher.getLastName().equalsIgnoreCase(lastName)) //If the teacher is found with those names
            {
                System.out.println("Is this the teacher that you would like to change?");
                System.out.println("Please enter yes or no.");
                System.out.println(teacher.toString()); //Just in case the user got the wrong person 
                
                answer = stdin.readLine();
                
                if (answer.equalsIgnoreCase("yes"))
                {
                    System.out.println("What kind of information are you looking to change?"); //Give different options for changing 
                    System.out.println("1. First name");
                    System.out.println("2. Last name");
                    System.out.println("3. Address");
                    System.out.println("4. Phone number");
                    System.out.println("5. Go back to main menu");
                    answer = stdin.readLine();
                    
                    while (choices == false)
                    {
                        if (answer.equals("1"))
                        {
                            choices = true;
                            System.out.println("What would you like to change the first name to?");
                            changedAnswer = stdin.readLine();

                            while (check == false)
                            {
                                checkTwo = 0;
                                for (int i = 0; i < changedAnswer.length(); i++)
                                {
                                    if (alpha.indexOf(changedAnswer.substring(i,i+1)) >= 0)
                                    {
                                        checkTwo += 1;
                                    }
                                }
                                if (checkTwo != changedAnswer.length())
                                {
                                    System.out.println("This is not the correct format for a name.");
                                    changedAnswer = stdin.readLine();
                                }
                                else
                                {
                                    check = true;
                                }

                            }
                            teacher.setFirstName(changedAnswer); //Change the name of the teacher
                            System.out.println("You have changed the first name."); //Let them know they have finished
                            return;
                        }
                        if (answer.equals("2"))
                        {
                            System.out.println("What would you like to change the last name to?");
                            changedAnswer = stdin.readLine();

                            while (check == false)
                            {
                                checkTwo = 0;
                                for (int i = 0; i < changedAnswer.length(); i++)
                                {
                                    if (alpha.indexOf(changedAnswer.substring(i,i+1)) >= 0)
                                    {
                                        checkTwo += 1;
                                    }
                                }
                                if (checkTwo != changedAnswer.length())
                                {
                                    System.out.println("This is not the correct format for a name.");
                                    changedAnswer = stdin.readLine();
                                }
                                else
                                {
                                    check = true;
                                }

                            }
                            teacher.setLastName(changedAnswer); //Change the last name of the teacher
                            System.out.println("You have changed the last name."); //Let them know they have finished
                            return;
                        }

                        if (answer.equals("3"))
                        {
                            System.out.println("What would you like to change the address to?");
                            changedAnswer = stdin.readLine();
                            teacher.setAddress(changedAnswer); //Change the address of the teacher
                            System.out.println("You have changed the address."); //Let them know they have finished
                            return;
                        }
                        if (answer.equals("4"))
                        {

                            System.out.println("What would you like to change the phone number to?");
                            changedAnswer = stdin.readLine();
                            for (int i = 0; i < changedAnswer.length(); i++)
                            {
                                if (alpha.indexOf(changedAnswer.substring(i,i+1)) >= 0 || (changedAnswer.length() != 10))
                                {
                                    System.out.println("This is not a correct phone number. Please try again.");
                                    changedAnswer = stdin.readLine();
                                } 
                            }
                            teacher.setPhoneNumber(changedAnswer); //Change the phone number of the teacher
                            System.out.println("You have changed the phone number."); //Let them know they have finished
                            return;
                        }
                        if (answer.equals("5"))
                        {
                            return;
                        }
                        else
                        {
                            System.out.println("Please enter a valid number.");
                            answer = stdin.readLine();
                        }
                    }
                }
                else if (answer.equalsIgnoreCase("no"))
                {
                    System.out.println("Try again!");
                    return;
                }
                else
                {
                    System.out.println("This is not the right format. Please enter yes or no.");
                    answer = stdin.readLine();
                }
            }
        }
        System.out.println("This teacher does not exist!");
        return;
    }
    
    
    public static void removeStudent(ArrayList<Students> Stlstudents) throws IOException
    {
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        
        System.out.println("");
        System.out.println("You have chosen to remove a student.");
        System.out.println("What is the student's ID: ");
        String answer = stdin.readLine();
        
        for (Students student: Stlstudents) //Iterate through student list to find the student
        {
            String id = Integer.toString(student.getId());
            if (id.equals(answer))
            {
                System.out.println("Is this the student that you want to remove?"); //In case they typed the number wrong
                System.out.println(student.toString());
                
                answer = stdin.readLine();
                
                if (answer.equalsIgnoreCase("yes"))
                {
                    Stlstudents.remove(student); //Remove the student from the school list of students 
                    System.out.println("The student has been removed."); //Let the user know they are done
                    return;
                }
                else if (answer.equalsIgnoreCase("no"))
                {
                    System.out.println("Try again please!");
                    return;
                }
                else
                {
                    System.out.println("Please enter yes or no.");
                    answer = stdin.readLine();
                }
            }
        }
        System.out.println("This student does not exist!");
    }
    
    public static void removeTeacher(ArrayList<Teachers> Stlteachers) throws IOException
    {
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        
        System.out.println("");
        System.out.println("You have chosen to remove a teacher.");
        System.out.println("What is the teacher's first name: ");
        String firstName = stdin.readLine();
        System.out.println("What is the teacher's last name: ");
        String lastName = stdin.readLine();
        String answer;
        
        for (Teachers teacher: Stlteachers) //Iterate through teacher list to find the teacher
        {
            String name = teacher.getFirstName();
            String nameTwo = teacher.getLastName();
            if (name.equals(firstName) && nameTwo.equals(lastName))
            {
                System.out.println("Is this the teacher that you want to remove?"); //In case they chose the wrong teacher
                System.out.println("Please enter yes or no.");
                System.out.println(teacher.toString());
                
                answer = stdin.readLine();
                
                if (answer.equalsIgnoreCase("yes"))
                {
                    Stlteachers.remove(teacher);    //Remove the teacher from the school list of teachers
                    System.out.println("The teacher has been removed.");
                    return;
                }
                else if (answer.equalsIgnoreCase("no"))
                {
                    System.out.println("Try again please!");
                    return;
                }
                else
                {
                    System.out.println("Please enter yes or no.");
                    answer = stdin.readLine();
                }
            }
        }
        System.out.println("This teacher does not exist!");
    }
    
    public static void displayCourses(ArrayList <Courses> courseList) throws IOException
    {
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        
        checkMainMenu = false;
        
        System.out.println("");
        System.out.println("You have chosen to display all the available courses.");
        System.out.println("If you would like to go back to the main menu, press 5."
                + " Else, please press any key.");
        String answer = stdin.readLine();
        
        if (answer.equals("5"))
        {
            return;
        }
        
        for (Courses course: courseList) //iterate through all the course list 
        {
            if (course.checkFullness() == false) //If the course still has some available space
            {
                System.out.println("Course: " + course.getCourse()); //Display the course information 
                System.out.println("Course code: " + course.getCourseCode());
                System.out.println("");
            }
        }
    }
            
    
    public static void registerStudent(ArrayList<Students> STLstudents) throws IOException
    {
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        
        checkMainMenu = false;
       
        System.out.println("");
        System.out.println("You have chosen to register a student. If you would like to go back, press 5. Press any key to begin.");
        String answer = stdin.readLine();
        String alpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"; //To check for format 
        String bdayForm = "1234567890/"; //To check for format 
        boolean check = false;
        int checkTwo = 0;
        
        if (answer.equals("5"))
        {
            return;
        }
        else
        {
            System.out.println("Enter your first name: ");
            String name = stdin.readLine();
            
            while (check == false)
            {
                checkTwo = 0;
                for (int i = 0; i < name.length(); i++)
                {
                    if (alpha.indexOf(name.substring(i,i+1)) >= 0)
                    {
                        checkTwo += 1;
                    }
                }
                if (checkTwo != name.length() || name.equals(""))
                {
                    System.out.println("This is not the correct format for a name.");
                    name = stdin.readLine();
                }
                else
                {
                    check = true;
                }
                
            }
            
            check = false;
            System.out.println("Enter your last name: ");
            String lastName = stdin.readLine();
            
            while (check == false)
            {
                checkTwo = 0;
                for (int i = 0; i < lastName.length(); i++)
                {
                    if (alpha.indexOf(lastName.substring(i,i+1)) >= 0)
                    {
                        checkTwo += 1;
                    }
                }
                if (checkTwo != lastName.length())
                {
                    System.out.println("This is not the correct format for a last name.");
                    lastName = stdin.readLine();
                }
                else
                {
                    check = true;
                }
                
            }
           
            check = false;
            System.out.println("Enter your birthday in the format of mm/dd/yyyy: ");
            String birthday = stdin.readLine();
            while (check == false)
            {
                checkTwo = 0;
                for (int i = 0; i < birthday.length(); i++)
                {
                    if (bdayForm.indexOf(birthday.substring(i,i+1)) >= 0)
                    {
                        checkTwo += 1;
                    }
                }
                if (checkTwo != 10)
                {
                    System.out.println("This is not the correct format for a birthday.");
                    birthday = stdin.readLine();
                }
                else
                {
                    check = true;
                }
                
            }
            
            
            System.out.println("Enter your age: ");
            String age = stdin.readLine();
            
            check = false;
            System.out.println("Enter your service hours: ");
            String hours = stdin.readLine();
            while (check == false)
            {
                checkTwo = 0;
                for (int i = 0; i < hours.length(); i++)
                {
                    if (alpha.indexOf(hours.substring(i,i+1)) < 0)
                    {
                        checkTwo += 1;
                    }
                }
                if (checkTwo != hours.length())
                {
                    System.out.println("This is not the correct format for hours.");
                    hours = stdin.readLine();
                }
                else
                {
                    check = true;
                }
                
            }
            
            System.out.println("Enter your address: ");
            String address = stdin.readLine();
            
            check = false;
            System.out.println("Enter your phone number with just numbers: ");
            String phoneNumber = stdin.readLine();
            while (check == false)
            {
                checkTwo = 0;
                for (int i = 0; i < phoneNumber.length(); i++)
                {
                    if (alpha.indexOf(phoneNumber.substring(i,i+1)) < 0)
                    {
                        checkTwo += 1;
                    }
                }
                if (checkTwo != 10)
                {
                    System.out.println("This is not the correct format for a phone number.");
                    phoneNumber = stdin.readLine();
                }
                else
                {
                    check = true;
                }
                
            }
            
            check = false;
            System.out.println("Enter your locker combination (6 digits): ");
            String lockerCombo = stdin.readLine();
            int lockCombo = 0;
            while (check == false)
            {
                checkTwo = 0;
                for (int i = 0; i < lockerCombo.length(); i++)
                {
                    if (alpha.indexOf(lockerCombo.substring(i,i+1)) < 0)
                    {
                        checkTwo += 1;
                    }
                }
                if (checkTwo != 6)
                {
                    System.out.println("This is not the correct format for a locker combo.");
                    System.out.println("Example should be: 021432");
                    lockerCombo = stdin.readLine();
                }
                else
                {
                    lockCombo = Integer.parseInt(lockerCombo);
                    check = true;
                }
                
            }
            
            
            System.out.println("Enter the student's accomodations, if none, write none: ");
            String accomodation = stdin.readLine();
            System.out.println("Enter the student's allergies, if none, write none: ");
            String allergies = stdin.readLine();
            System.out.println("Enter the student's physical needs, if none, write none: ");
            String physicals = stdin.readLine();
            System.out.println("Enter the student's epipen, if none, write none: ");
            String epipen = stdin.readLine();
            
            Students newPerson = new Students(new Lockers(lockCombo), name, lastName, birthday, age, hours, address, phoneNumber);
            STLstudents.add(newPerson);
            newPerson.setSpecialInfo(new SpecialInfo(accomodation,physicals,allergies,epipen));
            
            System.out.println("");
            System.out.println("You have successfully registered!");
            System.out.println("NEW STUDENT ADDED: ");
            System.out.println("Name: " + newPerson.getName() + " " + newPerson.getLastName() +
                    "\nID: " + newPerson.getId());
            return;
        } 
    }
    
    public static void teacherRegistration(ArrayList<Teachers> STLteachers) throws IOException
    {
        checkMainMenu = false;
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        
        System.out.println("You have chosen to register a teacher. If you would like to go back, press 5."
                + "Press any key to begin.");
        String answer = stdin.readLine();
        if (answer.equals("5"))
        {
            return;
        }  
        String alpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"; //to check for format
        String bdayForm = "1234567890/"; //to check for format 
        boolean check = false;
        int checkTwo = 0;
        
        System.out.println("Enter your first name: ");
        String name = stdin.readLine();

        while (check == false)
        {
            checkTwo = 0;
            for (int i = 0; i < name.length(); i++)
            {
                if (alpha.indexOf(name.substring(i,i+1)) >= 0)
                {
                    checkTwo += 1;
                }
            }
            if (checkTwo != name.length())
            {
                System.out.println("This is not the correct format for a name.");
                name = stdin.readLine();
            }
            else
            {
                check = true;
            }

        }

        check = false;
        System.out.println("Enter your last name: ");
        String lastName = stdin.readLine();
        

        while (check == false)
        {
            checkTwo = 0;
            for (int i = 0; i < lastName.length(); i++)
            {
                if (alpha.indexOf(lastName.substring(i,i+1)) >= 0)
                {
                    checkTwo += 1;
                }
            }
            if (checkTwo != lastName.length())
            {
                System.out.println("This is not the correct format for a last name.");
                lastName = stdin.readLine();
            }
            else
            {
                check = true;
            }

        }
        
        System.out.println("Enter your address: ");
        String address = stdin.readLine();
        
        System.out.println("Enter your phone number: ");
        String phoneNumber = stdin.readLine();
        for (int i = 0; i < phoneNumber.length(); i++)
        {
            if (alpha.indexOf(phoneNumber.substring(i,i+1)) >= 0 || (phoneNumber.length() != 10))
            {
                System.out.println("This is not a correct phone number. Please try again.");
                phoneNumber = stdin.readLine();
            } 
        }
        
        STLteachers.add(new Teachers(name, lastName, address, phoneNumber));
        System.out.println("");
        System.out.println("You have successfully registered!");
        return;
       
    }
    
    public static void courseMenu(ArrayList<Students> STLstudents, ArrayList<Courses> STLcourses, ArrayList<Teachers> STLteachers) throws IOException
    {
        /*
        This is the menu to display some course options 
        */
        checkMainMenu = false; //So the main menu is not displayed 
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        
        System.out.println("You have chosen to manage a student's course.");
        System.out.println("1. Drop a course");
        System.out.println("2. Change a course");
        System.out.println("3. Add a course");
        System.out.println("Press 5 to go back to the main menu");
        System.out.println("");
        
        String answer = stdin.readLine();
        if (answer.equals("1"))
        {
            dropCourse(STLstudents, STLcourses);
        }
        if (answer.equals("2"))
        {
            changeCourse(STLstudents, STLcourses);
        }
        if (answer.equals("3"))
        {
            addCourse(STLstudents, STLcourses);
        }
        if (answer.equals("5"))
        {
            return;
        }        
    }
    
    public static void dropCourse(ArrayList<Students> Stlstudents, ArrayList<Courses> Stlcourses) throws IOException
    {
         checkMainMenu = false;
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        
        int check = 0;
        int answerInt = 0;
        String answerTwo;
        String nums = "1234567890";
        boolean checkFormat = false;
        
       
        System.out.println("What is the id of the student would you like to help? "); 
        String answer = stdin.readLine();
        while (checkFormat == false)
        {
            check = 0;
            for (int i = 0; i < answer.length(); i++)
            {
                if (nums.indexOf(answer.substring(i,i+1)) >= 0)
                {
                    check += 1;
                }
            }
            if (check != answer.length() || answer.equals(""))
            {
                System.out.println("This is not the correct format.");
                answer = stdin.readLine();
            }
            else
            {
                answerInt = Integer.parseInt(answer);
                checkFormat = true;
            }

        }
        
        for (Students student: Stlstudents)
        {
            if (student.getId() == answerInt)
            {
                System.out.println("What course would they like to drop? ");
                answer = stdin.readLine();
                
                for (Courses course: Stlcourses)
                {
                    if (course.getCourse().equals(answer) && (course.checkAdmittance(student) == true))
                    {
                        student.dropCourse(new Courses(answer, course.getCourseCode(), course.getCapNum(), course.getPeriod())); //Drop the course from the setudent
                        course.dropStudents(student); //Drop the student from the course 
                        System.out.println("The course has been dropped."); //Let them know they are done 
                        return;
                    }
                    else if (course.getCourse().equals(answer) && course.checkAdmittance(student) == false) //If they are not even in the class
                    {
                        System.out.println("This student is not in this class.");
                        return;
                    }
                }
                System.out.println("This course does not exist!");
                return;
            }
        }
        System.out.println("This student does not exist!");
        return;
    }
    
    public static void addCourse(ArrayList<Students> Stlstudents, ArrayList<Courses> Stlcourses) throws IOException
    {
         checkMainMenu = false;
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        
        int check = 0;
        int answerInt = 0;
        String answerTwo;
        String nums = "1234567890";
        boolean checkFormat = false;
        
       
        System.out.println("What is the id of the student would you like to help? "); 
        String answer = stdin.readLine();
        while (checkFormat == false)
        {
            check = 0;
            for (int i = 0; i < answer.length(); i++)
            {
                if (nums.indexOf(answer.substring(i,i+1)) >= 0)
                {
                    check += 1;
                }
            }
            if (check != answer.length() || answer.equals(""))
            {
                System.out.println("This is not the correct format.");
                answer = stdin.readLine();
            }
            else
            {
                answerInt = Integer.parseInt(answer);
                checkFormat = true;
            }

        }
        
        for (Students student: Stlstudents)
        {
            if (student.getId() == answerInt)
            {
                System.out.println("What is the course code of the course they would like to add? ");
                for (Courses course: Stlcourses) //iterate through all the course list 
                {
                    if (course.checkFullness() == false) //If the course still has some available space
                    {
                        System.out.println("Course: " + course.getCourse()); //Display the course information 
                        System.out.println("Course code: " + course.getCourseCode());
                        System.out.println("");
                    }
                }
                answerTwo = stdin.readLine();
                
                for (Courses course: Stlcourses)
                {
                    if (course.getCourseCode().equals(answerTwo) && (course.checkAdmittance(student) == false)) //If there is some available space
                    {
                        student.addCourse(new Courses(answerTwo, course.getCourseCode(), course.getCapNum(), course.getPeriod()));
                        course.addStudents(student); 
                        
                        System.out.println("This course has been added."); //Let the user know they are done
                        
                        return;
                    }
                }
                System.out.println("This course does not exist!");
                return;
            }
        }
        System.out.println("This student does not exist!");
        return;
    }
    
    public static void changeCourse(ArrayList<Students> Stlstudents, ArrayList<Courses> Stlcourses) throws IOException
    {
         checkMainMenu = false;
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        
        int check = 0;
        int answerInt = 0;
        String answerTwo;
        String nums = "1234567890";
        boolean checkFormat = false;
        boolean checkCourse = false;
        
       
        System.out.println("What is the id of the student would you like to help? "); 
        String answer = stdin.readLine();
        while (checkFormat == false)
        {
            check = 0;
            for (int i = 0; i < answer.length(); i++)
            {
                if (nums.indexOf(answer.substring(i,i+1)) >= 0)
                {
                    check += 1;
                }
            }
            if (check != answer.length() || answer.equals(""))
            {
                System.out.println("This is not the correct format.");
                answer = stdin.readLine();
            }
            else
            {
                answerInt = Integer.parseInt(answer);
                checkFormat = true;
            }

        }
        String answerThree;
        
        for (Students student: Stlstudents)
        {
            if (student.getId()== answerInt)
            {
                System.out.println("What is the course code of the old course they would like to change? ");
                answerThree = stdin.readLine();
                
                System.out.println("What is the course code of the new course they would like to change to? ");
                System.out.println("");
                for (Courses course: Stlcourses) //iterate through all the course list 
                {
                    if (course.checkFullness() == false) //If the course still has some available space
                    {
                        System.out.println("Course: " + course.getCourse()); //Display the course information 
                        System.out.println("");
                        System.out.println("Course code: " + course.getCourseCode());
                    }
                }
                answerTwo = stdin.readLine();
                
                Courses newCourse = null;
                Courses oldCourse = null;
                
                for (Courses course: Stlcourses)
                {
                    if (course.getCourseCode().equals(answerTwo))
                    {
                        newCourse = course;
                    }
                    if (course.getCourseCode().equals(answerThree))
                    {
                        oldCourse = course;
                    }
                    //This is iterating through to find the course and set it to variables 
                }
                
                if (newCourse != null && oldCourse != null)
                {
                    if (newCourse.checkFullness() == true)
                    {
                        System.out.println("This course is full. They cannot take this!");
                        return;
                    }
                    if (newCourse.getPeriod() != oldCourse.getPeriod())
                    {
                        System.out.println("The classes do not run at the same time!");
                        return;
                    }
                    else 
                    {
                        student.dropCourse(oldCourse); //Drop the old course 
                        oldCourse.dropStudents(student);
                        student.addCourse(newCourse); //Add the new course that they wanted in place
                        newCourse.addStudents(student);
                        System.out.println("They have successfully changed their courses."); //Let them know they have changed
                        return;
                    }
                }
                return;
            }
        }
        System.out.println("This student does not exist!");
        return;
    }
    
    public static void searchMenu(ArrayList<Students> Stlstudents) throws IOException
    {
        /*
        This is the search menu for the student 
        */
        checkMainMenu = false;
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        
        System.out.println("You have chosen to look for a student.");
        System.out.println("1. Search by name"); //Option to search by name
        System.out.println("2. Search by student number"); //Option to search by student menu 
        System.out.println("Press 5 to go back to the main menu");
        System.out.println("");
        
        String answer = stdin.readLine();
        ArrayList<Courses> courseSched = new ArrayList<Courses>();
        
        if (answer.equals("1"))
        {
            System.out.println("What is the student's first name? ");
            String firstName = stdin.readLine();
            
            System.out.println("What is the student's last name? ");
            String lastName = stdin.readLine();
            
           
            for (Students student: Stlstudents)
            {
                if (student.getName().equals(firstName) && student.getLastName().equals(lastName))
                {
                    courseSched = student.getCoursesList();
                    for (int i = 0; i < courseSched.size(); i++)
                    {
                        System.out.println(courseSched.get(i));
                    }
                    System.out.println(student.toString());
                   
                    return;
                }
            }

        }
        
        if (answer.equals("2"))
        {
            System.out.println("What is the student's number? ");
            answer = stdin.readLine();
            
            for (Students student: Stlstudents)
            {
                if (student.getId() == Integer.parseInt(answer))
                {
                    courseSched = student.getCoursesList();
                    for (int i = 0; i < courseSched.size(); i++)
                    {
                        System.out.println(courseSched.get(i));
                    }
                    System.out.println(student.toString());
                    return;
                }
            }
        }
        
        if (answer.equals("5"))
        {
            return;
        }
        
        System.out.println("");   
    
    }
    
    public static void teacherCourseMenu(ArrayList<Courses> Stlcourses, ArrayList<Teachers> Stlteachers) throws IOException
    {
        /* 
        This is the menu managing a teacher's classes
        */
        checkMainMenu = false;
        InputStreamReader inStream = new InputStreamReader( System.in ) ;
        BufferedReader stdin = new BufferedReader( inStream );
        
        System.out.println("You have chosen to manage a teacher's classes.");
        System.out.println("1. Add a class");
        System.out.println("2. Drop a class");
        String answer = stdin.readLine();
        String alpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"; //Checking format 
        
        
        if (answer.equals("1"))
        {
            System.out.println("What is the first name of the teacher? ");
            String firstName = stdin.readLine();
            boolean checkFormat = false;
        
            while (checkFormat == false)
            {
                for (int i = 0; i < firstName.length(); i++)
                {
                    if (alpha.indexOf(firstName.substring(i,i+1)) >= 0)
                    {
                        checkFormat = true;
                    }
                    else if (i == firstName.length())
                    {
                        System.out.println("Please enter a proper ID.");
                        firstName = stdin.readLine();
                    }
                }
            }
            
            checkFormat = false;
            
            System.out.println("What is the last name of the teacher? ");
            String lastName = stdin.readLine();
            while (checkFormat == false)
            {
                for (int i = 0; i < lastName.length(); i++)
                {
                    if (alpha.indexOf(lastName.substring(i,i+1)) >= 0)
                    {
                        checkFormat = true;
                    }
                    else if (i == lastName.length())
                    {
                        System.out.println("Please enter a proper ID.");
                        lastName = stdin.readLine();
                    }
                }
            }
        
            for (Teachers teacher: Stlteachers)
            {
                if (teacher.getFirstName().equals(firstName) && teacher.getLastName().equals(lastName))
                {
                    System.out.println("What course would they like to add? ");
                    String newCourse = stdin.readLine();


                    for (Courses course: Stlcourses)
                    {
                        if (course.getCourse().equals(newCourse))
                        {
                            if (course.getTeacher() == null)
                            {
                                teacher.addCourses(course);
                                course.setTeacher(teacher);
                                return;
                            }
                            else
                            {
                                System.out.println("This course already has a teacher!");
                                return;
                            }
                        }
                    }
                    System.out.println("These courses do not exist!");
                    return;
                }
            }
            System.out.println("This teacher does not exist!");
            return;
        }
        
        if (answer.equals("2"))
        {
            System.out.println("What is the first name of the teacher? ");
            String firstName = stdin.readLine();
            boolean checkFormat = false;
        
            while (checkFormat == false)
            {
                for (int i = 0; i < firstName.length(); i++)
                {
                    if (alpha.indexOf(firstName.substring(i,i+1)) >= 0)
                    {
                        checkFormat = true;
                    }
                    else if (i == firstName.length())
                    {
                        System.out.println("Please enter a proper ID.");
                        firstName = stdin.readLine();
                    }
                }
            }
            
            checkFormat = false;
            
            System.out.println("What is the last name of the teacher? ");
            String lastName = stdin.readLine();
            while (checkFormat == false)
            {
                for (int i = 0; i < lastName.length(); i++)
                {
                    if (alpha.indexOf(lastName.substring(i,i+1)) >= 0)
                    {
                        checkFormat = true;
                    }
                    else if (i == lastName.length())
                    {
                        System.out.println("Please enter a proper ID.");
                        lastName = stdin.readLine();
                    }
                }
            }
            
            for (Teachers teacher: Stlteachers)
            {
                if (teacher.getFirstName().equals(firstName) && teacher.getLastName().equals(lastName))
                {
                    System.out.println("What course would they like to drop? ");
                    String oldCourse = stdin.readLine();

                    for (Courses course: Stlcourses)
                    {
                        if (course.getCourse().equals(oldCourse))
                        {
                            teacher.dropCourses(course);
 
                            return;
                        }
                    }
                    System.out.println("This course does not exist!");
                    return;
                }
            }
            System.out.println("This teacher does not exist!");
            return;
            
            
        }
        
        
    }
    
}