/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schoolregistration;

/**
 *
 * @author lizziekim
 */
public class SpecialInfo {
    
    private String accomodation, physical, allergy, epipen;//This will be the place for special information 

    public SpecialInfo(String accomodation, String physical, String allergy, String epipen) {
        this.accomodation = accomodation; 
        this.physical = physical;
        this.allergy = allergy;
        this.epipen = epipen;
    }

    public void setAccomodation(String accomodation) {
        this.accomodation = accomodation;
    }

    public void setAllergy(String allergy) {
        this.allergy = allergy;
    }

    public void setEpipen(String epipen) {
        this.epipen = epipen;
    }

    public void setPhysical(String physical) {
        this.physical = physical;
    }
    
    

    public String getAccomodation() {
        return accomodation;
    }

    public String getPhysical() {
        return physical;
    }

    public String getAllergy() {
        return allergy;
    }

    public String getEpipen() {
        return epipen;
    }
    
    

    @Override
    public String toString() {
        return "\n" + "Accomodation: " + accomodation + "\nPhysical Needs: " + physical
                + "\nAllergies: " + allergy + "\nEpipen: " + epipen; 
    }
    
    
    
}
