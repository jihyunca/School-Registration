/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schoolregistration;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public class Students {
    
    private String name, lastName, birthday, age, serviceHours, address, phoneNumber; //Assign values to the student
    private Lockers locker; //Assign a locker object 
    private ArrayList<Courses> coursesList = new ArrayList<Courses>(); //Asssign a list of courses to keeep track of what the student is taking
    private SpecialInfo specialInfo; //Assign special info object 
    
    
    private static AtomicInteger nextId=new AtomicInteger();
    private int id; //Generates an ID chronologically 
    
    public Students(Lockers locker, String name, String lastName, String birthday, String age, String serviceHours,String address, String phoneNumber)
    {
        this.locker = locker;
        //this.timeTable = timeTable;
        //timeTable = new timeTable();
        
        this.birthday = birthday;
        this.name = name;
        this.lastName = lastName;
        this.age = age;
        this.serviceHours = serviceHours;
        this.address = address;
        this.phoneNumber = phoneNumber;
        id = nextId.incrementAndGet();
        this.coursesList = coursesList;
        
        for (int i = 0; i < 4; i++)
        {
            coursesList.add(new Courses("Spare", "", 30, i)); //Inititally start with the four spare courses
        }
        
       
    }
    
    void addCourse(Courses course) //Method for adding a course 
    {
       for (int i = 0; i < coursesList.size(); i++)
       {
           if (coursesList.get(i).getCourse().equals("Spare") && (coursesList.get(i).getCapNum() == course.getCapNum()))
           {
               coursesList.set(i, course); //If it is a spare, put the course in right away 
               return;      
           }
           else if ((coursesList.get(i).getCapNum() != course.getCapNum()))
           {
               System.out.println("This class is not available at this period.");
           }
           else if (i == 3)
           {
               System.out.println("This student is already full with courses."); //If they are full with courses, let the user know 
           }
        }
        
    }
  
    void dropCourse(Courses course)
    {
        for (int i = 0; i < coursesList.size(); i++)
        {
            if (coursesList.contains(course)) //If the student does have this class 
            {
                coursesList.set(i, new Courses("Spare", "", 30, i)); //Set the class as a spare instead 
                System.out.println("This student has dropped this class.");
                course.setTeacher(null);
                return;
            }
            else if (i == 3)
            {
                System.out.println("This student does not even have this class.");
                return;
            }
        }
        
    }
    
    
    
    public Lockers getLocker() {
        return locker;
    }

    public void setSpecialInfo(SpecialInfo specialInfo) {
        this.specialInfo = specialInfo;
    }
    
    

    public SpecialInfo getSpecialInfo() {
        return specialInfo;
    }
    
    
    
    public String getBirthday()
    {
        return birthday;
    }

    public String getAddress() {
        return address;
    }

    public String getAge() {
        return age;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getServiceHours() {
        return serviceHours;
    }

    public String getName() {
        return name;
    }

    public String getLastName() {
        return lastName;
    }

    public int getId() {
      
        return id;
    }


    public ArrayList<Courses> getCoursesList() {
        return coursesList;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setServiceHours(String serviceHours) {
        this.serviceHours = serviceHours;
    }
    
    
   
    @Override
    public String toString() {
        
        
        return "\n" + "The student is: " + name + " " + lastName + "\nBirthday is: " + birthday + 
                "\nService hours are: " + serviceHours + 
         "\nPhone number is " + phoneNumber + "\nAddress is: " + address + "\n" + locker + "\nID is " + id
                + "\n" + "Special information: " + specialInfo;
                        
              
                      //This prints out everything as a string 
    }
    
}


