/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schoolregistration;
import java.util.ArrayList;

/**
 *
 * @author lizziekim
 */
public class Teachers {
    
    private String firstName, lastName, address, phoneNumber; //The personal information of the teacher as variables
    private ArrayList<Courses> coursesList = new ArrayList<Courses>(); //Add a list of courses like a schedule
    
    public Teachers(String firstName, String lastName, String address, String phoneNumber)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.phoneNumber = phoneNumber; 
        
        for (int i = 0; i < 4; i++)
        {
            coursesList.add(new Courses("Spare", "", 30, i)); //Initially start off with four spares 
        }
        
    }
    
    public void addCourses(Courses course) //Method for adding classes for a teacher 
    {
        for (int i = 0; i < coursesList.size(); i++)
        {
           if (coursesList.get(i).getCourse().equals("Spare")) //If the teacher has a spare 
           {
               coursesList.set(i, course); //Set the first spare found as the class
               System.out.println("This teacher has added this class!"); //Let the user know 
               return;      
           }
           else if (i == 3)
           {
               System.out.println("This teacher is already full with courses."); //If the teacher already has four classes then let them know
               return;
           }
        }
    
    }
    
    public void dropCourses(Courses course) //Method for dropping courses 
    {
        for (int i = 0; i < coursesList.size(); i++)
        {
            if (coursesList.contains(course)) //If the teacher does have this class 
            {
                coursesList.set(i, new Courses("Spare", "", 30, i)); //Set the class as a spare instead 
                System.out.println("This teacher has dropped this class.");
                course.setTeacher(null);
                return;
            }
            else if (i == 3)
            {
                System.out.println("This teacher does not even have this class.");
                return;
            }
        }
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    public String getFirstName()
    {
        return firstName;
    }
    
    public String getLastName()
    {
        return lastName;
    }

    public String getAddress() {
        return address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public ArrayList<Courses> getCoursesList() {
        return coursesList;
    }
    
    

    @Override
    public String toString() {
        return "First name: " + firstName + "\nLast name: " + lastName + "\nPhone number: " + phoneNumber;
                 
    }
    
    
    
    
    
}
